DBMS (Database management syetem ) is software that allows users to create manage , and manipultae databse efficiently, It provides an interface to strore , retrive , update and manage data while ensuring security, consistency and integrity.

Types of DBMS:

relational DBMS (RDBMS) - uses tables (sql-based , e.g., mysql , Postgresql, Oracle ).

nosql DBMS - handles unstructured data (e.g mangoDB, dassandra).

huercahical DBMS - Organizes data on a tree like structure ( e.h,. IBM information management system).

network DBMS  -- 

Uses a graph - like structure (e.g., integrated  data store ).

Note : for local devlopment and understanding purpose , we are using sqllite database.

step1 : create a DB in your local system 

step2:you need to create schemas for diffirent entities of your MHR prject.
