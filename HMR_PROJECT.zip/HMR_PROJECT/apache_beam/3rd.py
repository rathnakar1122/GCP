# import apache_beam as beam
# from apache_beam.options.pipeline_options import PipelineOptions
# import os
# os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"C:\ENV\hopeful-land-452112-j5-47b5f18a317f.json"
# gcs_file_path = 'gs://csv-file-data/employee.csv'

# pipeline_options = PipelineOptions(
#     runner="DataflowRunner"  # Change to "DataflowRunner" for GCP
# )
# with beam.Pipeline(options=pipeline_options) as p:
#     lines = (
#         p
#         | "Read CSV from GCS" >> beam.io.ReadFromText(gcs_file_path, skip_header_lines=1)
#         | "Print Lines" >> beam.Map(print)
#     )

import pandas as pd
import gcsfs  # Required for reading from GCS
from google.oauth2 import service_account
import pandas_gbq

credentials = service_account.Credentials.from_service_account_file(
    r"C:\ENV\hopeful-land-452112-j5-47b5f18a317f.json"
)
GCS_BUCKET_NAME = "csv-file-data"
GCS_FILE_PATH = "Department.csv"  
BQ_PROJECT_ID = "hopeful-land-452112-j5"
BQ_DATASET = "DEV"  
BQ_TABLE = "department"

fs = gcsfs.GCSFileSystem(token=credentials)
with fs.open(f"{GCS_BUCKET_NAME}/{GCS_FILE_PATH}", "rb") as f:
    df = pd.read_csv(f)
pandas_gbq.to_gbq(df, f"{BQ_DATASET}.{BQ_TABLE}", project_id=BQ_PROJECT_ID, if_exists="replace", credentials=credentials)
print("Data successfully loaded into BigQuery!")
