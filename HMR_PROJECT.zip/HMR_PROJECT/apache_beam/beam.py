import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
import argparse
import re
from google.cloud import bigquery
from apache_beam.runners.runner import PipelineState

# BigQuery table specs
delivered_table_spec = 'vast-arena-452608-m1.zomato_orders.delivered_orders'
other_table_spec = 'vast-arena-452608-m1.zomato_orders.other_status_orders'

# Command-line argument parser
parser = argparse.ArgumentParser()
parser.add_argument('--input', dest='input', required=True, help='Input file to process.')
path_args, pipeline_args = parser.parse_known_args()
inputs_pattern = path_args.input

# Pipeline options
options = PipelineOptions(pipeline_args)
p = beam.Pipeline(options=options)

# ---------------- Transformation functions ----------------

def remove_last_colon(row):
    cols = row.split(',')
    if len(cols) > 4 and cols[4].endswith(':'):
        cols[4] = cols[4][:-1]
    return ','.join(cols)

def remove_special_characters(row):
    cols = row.split(',')
    clean_cols = [re.sub(r'[?%&]', '', col) for col in cols]
    return ','.join(clean_cols)

def print_row(row):
    print(row)

def to_json(csv_str):
    fields = csv_str.split(',')
    if len(fields) < 12:
        return {}  # Skip malformed rows
    return {
        "customer_id": fields[0],
        "date": fields[1],
        "timestamp": fields[2],
        "order_id": fields[3],
        "items": fields[4],
        "amount": fields[5],
        "mode": fields[6],
        "restaurant": fields[7],
        "status": fields[8],
        "ratings": fields[9],
        "feedback": fields[10],
        "new_col": fields[11],
    }

# ---------------- Data Processing Pipeline ----------------

cleaned_data = (
    p
    | "Read CSV" >> beam.io.ReadFromText(inputs_pattern, skip_header_lines=1)
    | "Remove Last Colon" >> beam.Map(remove_last_colon)
    | "Convert to Lowercase" >> beam.Map(lambda row: row.lower())
    | "Remove Special Characters" >> beam.Map(remove_special_characters)
    | "Add New Column" >> beam.Map(lambda row: row + ',1')
)

delivered_orders = (
    cleaned_data
    | "Filter Delivered" >> beam.Filter(lambda row: row.split(',')[8] == 'delivered')
)

other_orders = (
    cleaned_data
    | "Filter Others" >> beam.Filter(lambda row: row.split(',')[8] != 'delivered')
)

# Count and print metrics
(
    cleaned_data
    | "Count Total" >> beam.combiners.Count.Globally()
    | "Map Total" >> beam.Map(lambda x: f'Total Count: {x}')
    | "Print Total" >> beam.Map(print_row)
)

(
    delivered_orders
    | "Count Delivered" >> beam.combiners.Count.Globally()
    | "Map Delivered" >> beam.Map(lambda x: f'Delivered Count: {x}')
    | "Print Delivered" >> beam.Map(print_row)
)

(
    other_orders
    | "Count Others" >> beam.combiners.Count.Globally()
    | "Map Others" >> beam.Map(lambda x: f'Others Count: {x}')
    | "Print Others" >> beam.Map(print_row)
)

# ---------------- BigQuery Setup ----------------

client = bigquery.Client()
dataset_id = "vast-arena-452608-m1.zomato_orders"

try:
    client.get_dataset(dataset_id)
except Exception:
    dataset = bigquery.Dataset(client.dataset(dataset_id))
    dataset.location = "US"
    dataset.description = "Dataset for food orders"
    client.create_dataset(dataset, exists_ok=True)

# BigQuery table schema
table_schema = (
    'customer_id:STRING,date:STRING,timestamp:STRING,order_id:STRING,'
    'items:STRING,amount:STRING,mode:STRING,restaurant:STRING,'
    'status:STRING,ratings:STRING,feedback:STRING,new_col:STRING'
)

# Write delivered orders to BigQuery
(
    delivered_orders
    | "Delivered to JSON" >> beam.Map(to_json)
    | "Write Delivered to BQ" >> beam.io.WriteToBigQuery(
        delivered_table_spec,
        schema=table_schema,
        create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
        write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
        additional_bq_parameters={'timePartitioning': {'type': 'DAY'}}
    )
)

# Write other orders to BigQuery
(
    other_orders
    | "Others to JSON" >> beam.Map(to_json)
    | "Write Others to BQ" >> beam.io.WriteToBigQuery(
        other_table_spec,
        schema=table_schema,
        create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
        write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
        additional_bq_parameters={'timePartitioning': {'type': 'DAY'}}
    )
)

# ---------------- Run the Pipeline ----------------

result = p.run()
result.wait_until_finish()

if result.state == PipelineState.DONE:
    print('Pipeline completed successfully!')
else:
    print('Pipeline failed!')
