import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
import os

# Set up Google Cloud credentials
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"C:\ENV\hopeful-land-452112-j5-47b5f18a317f.json"

# GCS file path
gcs_file_path = 'gs://csv-file-data/employee.csv'

# Define pipeline options (uncomment when running on Dataflow)
# pipeline_options = PipelineOptions(
#     runner="DataflowRunner",
#     project="your-gcp-project-id",
#     region="your-region",
#     temp_location="gs://your-temp-bucket/temp/"
# )

def record_filter(row):
    """Filter rows where the first column value is between 11 and 15 (inclusive)."""
    try:
        first_column_value = int(row.split(",")[0])  # Convert first column to integer
        return 101 <= first_column_value <= 105
    except ValueError:
        return False  # Skip rows that don't have a valid integer in the first column

# Create Apache Beam pipeline
with beam.Pipeline() as p:
    lines = (
        p
        | "Read CSV from GCS" >> beam.io.ReadFromText(gcs_file_path, skip_header_lines=1)
        | "Filter Records" >> beam.Filter(record_filter)
        | "Print Filtered Rows" >> beam.Map(print)
    )
