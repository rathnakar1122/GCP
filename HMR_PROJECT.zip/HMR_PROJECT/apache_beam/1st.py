import apache_beam as beam

data = [
    {"name": "Alice Smith", "age": 25, "city": "Los Angeles"},
    {"name": "Bob Johnson", "age": 35, "city": "Chicago"},
    {"name": "Charlie Brown", "age": 28, "city": "Houston"}
]
# Define the Beam pipeline
with beam.Pipeline() as p:
    pcoll = (
        p   | "Reading-In-Memory _data" >> beam.Create(data)
            #| "Create PCollection" >> beam.Create(data)
            | "Print Elements" >> beam.Map(print)
    )
