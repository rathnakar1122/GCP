import os 
import apache_beam as beam 

# Set Google credentials properly
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"C:\ENV\hopeful-land-452112-j5-47b5f18a317f.json"

gcs_file_path = "gs://csv-file-data/customer.csv"

# Create a Beam pipeline
with beam.Pipeline() as pipeline:

    lines = (
        pipeline
        | "Read CSV File" >> beam.io.ReadFromText(gcs_file_path, skip_header_lines=1)  # Skip only 1 header row
        | "Print Lines" >> beam.Map(print)  # Print each row to verify output
    )
