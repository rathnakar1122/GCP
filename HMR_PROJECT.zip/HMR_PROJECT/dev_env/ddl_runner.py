import os
from db_connection import conn_and_cursor_creation as cc

# Establish database connection
conn, cursor = cc()

# Corrected variable name
dql_script_path = r"C:\ENV\PREP\2025\hyd_meto_project\ad_quries\ticket_data.sql"

# Read SQL script from file
with open(dql_script_path, 'r', encoding="utf-8") as sql_file:
    dql_script = sql_file.read()

# Execute the SQL script
cursor.execute(dql_script)

# Fetch all results
rows = cursor.fetchall()

# Print each row separately
for row in rows:
    print(row)

# Close the connection
conn.close()
