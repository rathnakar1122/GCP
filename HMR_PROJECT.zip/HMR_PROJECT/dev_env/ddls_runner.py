import os 
from db_connection import conn_and_cursor_creation as cc
conn, cursor = cc()

ddl_script_path = r""

# read the sql file 
with open(ddl_script_path, 'r') as sql_file:
    sql_script = sql_file.read()
ddl_script = sql_script
cursor .execute(ddl_script)

conn.commit()
conn.close()