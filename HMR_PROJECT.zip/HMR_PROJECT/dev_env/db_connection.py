import sqlite3

DB_NAME = ' HMR_METRO_DB.DB'

def db_connection():
    return sqlite3.connect(DB_NAME)

def conn_and_cursor_creation():
    conn = db_connection()
    cursor = conn.cursor()
    return conn, cursor