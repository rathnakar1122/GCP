import mysql.connector
import pandas as pd

db_connection = mysql.connector.connect(
    host="your_host",
    user="your_user",
    password="your_password",
    database="your_database"
)

def execute_query(query, fetch=False):
    try:
        cursor = db_connection.cursor()
        cursor.execute(query)  

        if fetch:
            result = cursor.fetchall()
            columns = [col[0] for col in cursor.description] 
            return pd.DataFrame(result, columns=columns)

        db_connection.commit()
        print("Query executed successfully")

    except Exception as e:
        print(f"Error working with Database: {e}")

    finally:
        cursor.close()  

select_query = 