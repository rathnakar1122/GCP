import mysql.connector

# Replace with your MySQL details
db_config = {
    "host": "localhost",  # Change if MySQL is running on a different host
    "user": "root",
    "password": "Yesurathnam@1990",
    "database": "MHR_METRO_DB.DB"  # Optional, specify if connecting to a specific DB
}

try:
    # Establishing connection
    conn = mysql.connector.connect(**db_config)

    if conn.is_connected():
        print("Connected to MySQL successfully!")

        # Create a cursor object
        cursor = conn.cursor()

        # Execute a simple query
        cursor.execute("SHOW DATABASES")

        print("Databases available:")
        for db in cursor.fetchall():
            print(db[0])

        # Close the cursor and connection
        cursor.close()
        conn.close()

except mysql.connector.Error as err:
    print(f"Error: {err}")
