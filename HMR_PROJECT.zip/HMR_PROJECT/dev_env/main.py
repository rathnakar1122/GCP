import os
import datetime
from db_connection import conn_and_cursor_creation as cc
conn, cursor = cc()

# the above code part is relating to importing section
def fare_generator():
    list_of_stations_with_points_gap = [1,10,2,9,3,7,4] 

    def taking_input_for_station_ids():
        stations = {
        1: "Miyapur",
        2: "Ameerpet",
        3: "MG Bus Station",
        4: "L B Nagar"
        }
        # Display the available stations
        print("Available Station IDs:")
        for station_id, station_name in stations.items():
            print(f"{station_id}: {station_name}")
        while True:
                s_s_id = int(input("Enter the Source station id: "))
                t_s_id = int(input("Enter the Target station id: "))
                if s_s_id in [1,2,3,4] and t_s_id in [1,2,3,4] and (s_s_id!=t_s_id):  
                    return s_s_id, t_s_id,stations[s_s_id],stations[t_s_id]
                else:
                    print("These are not valid ids you entered.\nOne of your source or target ids are not in given list or same.\nPlease Enter Correct Ids: ")
        
    s_s_id, t_s_id,From_Location, To_Location = taking_input_for_station_ids() 
    # print(s_s_id,t_s_id)
    if  s_s_id < t_s_id:
        # The following for loop iterates over the index values of the list. 
        idx_of_s_s_id = list_of_stations_with_points_gap.index(s_s_id)
        idx_of_t_s_id = list_of_stations_with_points_gap.index(t_s_id)
        # print(idx_of_s_s_id, idx_of_t_s_id)
        total_distance = 0
        for v in list_of_stations_with_points_gap[idx_of_s_s_id+1:idx_of_t_s_id+1:2]:  
            total_distance = total_distance + v
    else:
        # The following for loop iterates over the index values of the list. 
        idx_of_s_s_id = list_of_stations_with_points_gap.index(s_s_id)
        idx_of_t_s_id = list_of_stations_with_points_gap.index(t_s_id)
        # print(idx_of_s_s_id, idx_of_t_s_id)
        total_distance = 0
        for v in list_of_stations_with_points_gap[idx_of_s_s_id-1:idx_of_t_s_id:-1][::2]:  
            total_distance = total_distance + v
    
    # print(total_distance)
    return From_Location, To_Location, total_distance


def ticket_generation(To_Location,From_Location,Price ,Ticket_Type,Date_And_Time):  # parameters passing
    print("\033[1;34m======================================\033[0m")
    print("\033[1;32m         TRAIN TICKET DETAILS        \033[0m")
    print("\033[1;34m======================================\033[0m")
    print(f"\033[1;33mTo_Location: \033[0m\033[1;36m{To_Location}\033[0m")
    print(f"\033[1;33mFrom_Location: \033[0m\033[1;36m{From_Location}\033[0m")
    print(f"\033[1;33mPrice: \033[0m\033[1;36m{Price}\033[0m")
    print(f"\033[1;33mDate_And_Time: \033[0m\033[1;36m{Date_And_Time} INR\033[0m")
    print("\033[1;34m======================================\033[0m")



    return (To_Location,From_Location,Price ,Ticket_Type,Date_And_Time)
    
print("Please Enter The details for ticket issuing: ")
result = fare_generator()
# print(result)
From_Location = result[0]
To_Location = result[1]
Price = result[2]
Ticket_Type = 'SJT'
Date_And_Time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")  
# Generate Ticket
result = ticket_generation(To_Location, From_Location, Price, Ticket_Type, Date_And_Time)

# ✅ FIXED: Use Parameterized Query
dml_script = """INSERT INTO ticket (From_Location, To_Location, Price, Ticket_Type, Date_And_Time)
                VALUES (?, ?, ?, ?, ?)"""
cursor.execute(dml_script, result)
conn.commit()
conn.close()