import os
from db_connection import conn_and_cursor_creation as cc
conn, cursor = cc()

dml_script_path = r'C:\GCP-DE\HMRProject\dbms\dmls\insert_stations.sql'


# Read the SQL file
with open(dml_script_path, 'r') as sql_file:
    sql_script = sql_file.read()

dml_script = sql_script

cursor.execute(dml_script)

conn.commit()
conn.close()

