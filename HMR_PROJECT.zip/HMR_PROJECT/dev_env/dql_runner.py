import os
import sqlite3
import pandas as pd
from db_connection import conn_and_cursor_creation as cc

# Establish database connection
conn, cursor = cc()

# Define SQL script path
dql_script_path = r'C:\GCP-DE\HMRProject\dbms\ad_queries\ticket_data.sql'

# Check if the SQL file exists before reading
if not os.path.exists(dql_script_path):
    print(f"❌ Error: SQL file not found at {dql_script_path}")
    conn.close()
    exit(1)

# Read the SQL file
with open(dql_script_path, 'r') as sql_file:
    sql_script = sql_file.read()

# Execute SQL script
try:
    result = cursor.execute(sql_script)
    rows = result.fetchall()

    # Fetch column names
    columns = [desc[0] for desc in cursor.description]

    # Convert to Pandas DataFrame
    df = pd.DataFrame(rows, columns=columns)

    # Convert 'Date_And_Time' to date format if column exists
    if 'Date_And_Time' in df.columns:
        df["Date_And_Time"] = pd.to_datetime(df["Date_And_Time"]).dt.date

    # Print DataFrame
    print(df)

    # Define CSV path
    csv_path = r"C:\GCP-DE\HMRProject\processing\exporting_to_gcs\ticket_data.csv"

    # Save DataFrame to CSV (without index)
    df.to_csv(csv_path, index=False)

    print(f"\n✅ Data saved successfully at: {csv_path}")

except Exception as e:
    print(f"❌ Error executing SQL query: {e}")

finally:
    # Close the connection
    conn.close()
