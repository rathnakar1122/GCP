
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import db_connection as db_conn  # import 'plugins' folder
import pandas as pd
from google.cloud import storage
from io import StringIO


def run_db_task():
    """Use the connection from db_connection.py"""
    conn, cursor = db_conn.conn_and_cursor_creation()
    print("Database connection established:", conn)

    cursor.execute("SELECT * FROM hmr_db.ticket;")
    rows = cursor.fetchall()

    # GCS file path
    gcs_bucket_name = "hmr-conn-tt"
    today = datetime.now()
    
    # Format the date as YYYY_DD_MM
    date_str = today.strftime("y_%d_%m")

    # Generate the GCS blob name
    gcs_upload_blob_name = f"ticket_date_{date_str}.csv"

    # Authenticate using the service account
    client = storage.Client()
    bucket = client.bucket(gcs_bucket_name)

    # Get column names from cursor description
    columns = [desc[0] for desc in cursor.description]

    # Create DataFrame
    df = pd.DataFrame(rows, columns=columns)
    print(df)

    # Save DataFrame as CSV in memory
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)

    # Upload modified DataFrame to GCS
    blob_modified = bucket.blob(gcs_upload_blob_name)
    blob_modified.upload_from_string(csv_buffer.getvalue(), content_type="text/csv")

    print(f"Modified DataFrame saved as '{gcs_upload_blob_name}' in GCS")

    # Close connections
    cursor.close()
    conn.close()


default_args = {
    "owner": "airflow",
    "start_date": datetime(2024, 2, 20),
    "retries": 1,
}

dag = DAG(
    "custom_module_and_mysql_to_gcs_load_dag_v2",
    default_args=default_args,
    schedule_interval=None,
    catchup=False
)

run_task = PythonOperator(
    task_id="run_db_task",
    python_callable=run_db_task,
    dag=dag
)
