from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

def adding_two_numbers():
    num1 = 101
    num2 = 102
    print(num1 + num2)

def subtraction_two_numbers():
    num1 = 101
    num2 = 102
    print(num1 - num2)

default_args = {
    'owner': "airflow",
    'start_date': datetime(2025, 2, 20),
    'retries': 1,  # Removed extra space
    'retry_delay': timedelta(minutes=2)
}

dag = DAG(
    dag_id="sample_dag",
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False
)

task1 = PythonOperator(
    task_id='addition',
    python_callable=adding_two_numbers,
    dag=dag
)

tas2 = PythonOperator(
    task_id="subtraction",
    python_callable=subtraction_two_numbers,
    dag=dag
)

task1 >> tas2  # Corrected task dependency
