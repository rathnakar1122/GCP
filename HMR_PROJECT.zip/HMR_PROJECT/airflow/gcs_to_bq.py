from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python import PythonOperator
from google.cloud import storage, bigquery


# Default arguments for the DAG
default_args = {
    'owner': 'Airflow',  # Owner of the DAG
    'email_on_failure': False,  # Disable email notifications on failure
    'catchup': False,  # Prevent past runs from catching up
    'start_date': datetime(2025, 3, 28),  # DAG start date
    'end_date': datetime(2025, 4, 1),  # DAG end date
    'retries': 2,  # Number of retries on failure
    'retry_delay': timedelta(minutes=2),  # Delay between retries
}

# Python functions for DAG tasks
def create_bucket_class_location():
    """Create a new GCS bucket in the US region with the STANDARD storage class."""
    bucket_name = 'etl_gcs_bucket_standard'
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    bucket.storage_class = 'STANDARD'
    new_bucket = storage_client.create_bucket(bucket, location='US')
    print(f"Created bucket {new_bucket.name} in {new_bucket.location} region.")

def copying_csv_file_from_source_bucket_to_target_bucket():
    """Copy a CSV file from the source GCS bucket to the target GCS bucket."""
    source_bucket_name = 'abce'
    target_bucket_name = 'xyz'
    source_blob_name = 'abc_blob'
    target_blob_name = 'xyz_blob'

    storage_client = storage.Client()
    source_bucket = storage_client.bucket(source_bucket_name)
    source_blob = source_bucket.blob(source_blob_name)
    target_bucket = storage_client.bucket(target_bucket_name)

    source_bucket.copy_blob(source_blob, target_bucket, target_blob_name)
    print(f"File {source_blob_name} copied from {source_bucket_name} to {target_bucket_name} as {target_blob_name}.")

def listing_objects_in_a_gcs_bucket():
    """List all objects present in a specified GCS bucket."""
    bucket_name = 'target_bucket'
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blobs = bucket.list_blobs()

    print(f"Objects in bucket {bucket_name}:")
    for blob in blobs:
        print(blob.name)

def dataset_creation_in_bq():
    """Create a new dataset in BigQuery."""
    project_id = 'abc'
    bq_client = bigquery.Client()
    dataset_id = f"{project_id}.new_dataset"
    dataset = bigquery.Dataset(dataset_id)
    dataset.location = "US"
    bq_client.create_dataset(dataset, exists_ok=True)
    print(f"Dataset {dataset_id} created.")

def table_creation_in_bq():
    """Create a new table in the BigQuery dataset with a predefined schema."""
    project_id = "abc"
    dataset_id = "new_dataset"
    table_id = "new_table"
    client = bigquery.Client()
    table_ref = f"{project_id}.{dataset_id}.{table_id}"
    schema = [
        bigquery.SchemaField("full_name", "STRING", mode="REQUIRED"),
        bigquery.SchemaField("last_update", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("date", "TIMESTAMP", mode="REPEATED")
    ]
    table = bigquery.Table(table_ref, schema=schema)
    client.create_table(table, exists_ok=True)
    print(f"Table {table_ref} created.")

def loading_data_from_gcs_to_bq_table():
    """Load data from a CSV file stored in GCS into a BigQuery table."""
    client = bigquery.Client()
    project_id = 'abc'
    dataset_id = 'new_dataset'
    table_id = 'new_table'
    table_ref = f'{project_id}.{dataset_id}.{table_id}'
    uri = 'gs://xyz/data.csv'
    job_config = bigquery.LoadJobConfig(
        skip_leading_rows=1,  # Skip header row
        source_format=bigquery.SourceFormat.CSV,  # Specify CSV format
    )
    load_job = client.load_table_from_uri(uri, table_ref, job_config=job_config)
    load_job.result()  # Wait for job completion
    print(f"Loaded data into {table_ref} from {uri}.")

# DAG instance
#define the ETL workflow using Airflow
dag = DAG(
    dag_id='gcs_to_bq_etl',  # DAG name
    description='ETL DAG from GCS to BigQuery',
    default_args=default_args,
    schedule=None,
    catchup=False
)

# Task 1: Create a GCS bucket
task_1 = PythonOperator(
    task_id='creating_gcs_bucket',
    python_callable=create_bucket_class_location,
    dag=dag
)

# Task 2: Copy a CSV file from one GCS bucket to another
task_2 = PythonOperator(
    task_id='copying_csv_file_from_source_to_target_bucket',
    python_callable=copying_csv_file_from_source_bucket_to_target_bucket,
    dag=dag
)

# Task 3: List objects in the target GCS bucket
task_3 = PythonOperator(
    task_id='listing_objects_in_gcs_bucket',
    python_callable=listing_objects_in_a_gcs_bucket,
    dag=dag
)

# Task 4: Create a dataset in BigQuery
task_4 = PythonOperator(
    task_id='dataset_creation',
    python_callable=dataset_creation_in_bq,
    dag=dag
)

# Task 5: Create a table in BigQuery with a predefined schema
task_5 = PythonOperator(
    task_id='table_creation',
    python_callable=table_creation_in_bq,
    dag=dag
)

# Task 6: Load data from GCS into the BigQuery table
task_6 = PythonOperator(
    task_id='loading_data_from_gcs_to_bq_table',
    python_callable=loading_data_from_gcs_to_bq_table,
    dag=dag
)

# Define task dependencies
# The order ensures data is copied, listed, and properly stored before moving to BigQuery
task_1 >> task_2 >> task_3 >> task_4 >> task_5 >> task_6