from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.google.cloud.operators.dataflow import DataflowCreatePythonJobOperator
from airflow.providers.google.cloud.sensors.gcs import GCSObjectsWithPrefixExistenceSensor
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.operators.python import PythonOperator
from google.cloud import storage  
# Corrected import

# Default arguments
default_args = {
    'owner': 'Airflow',
    'start_date': datetime(2025, 4, 2),
    'retries': 0,
    'retry_delay': timedelta(seconds=50),
}

# Move file from 'food_orders_daily/' to 'processed/'
def list_files(bucket_name, prefix, processed_prefix='processed/', **kwargs):
    gcs_hook = GCSHook()
    files = gcs_hook.list(bucket_name, prefix=prefix)
    if files:
        source_object = files[0]
        file_name = source_object.split('/')[-1]
        destination_object = f"{processed_prefix.rstrip('/')}/{file_name}"

        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        source_blob = bucket.blob(source_object)
        destination_blob = bucket.blob(destination_object)

        destination_blob.upload_from_string(source_blob.download_as_text())
        source_blob.delete()

        # Push to XCom manually if needed (though return also works)
        kwargs['ti'].xcom_push(key='moved_file_path', value=destination_object)
        return destination_object
    return None

# Define DAG
with DAG('food_orders_dag_etl_v4',
         default_args=default_args,
         schedule_interval=None,
         catchup=False,
         max_active_runs=1) as dag:

    # Wait until file appears
    gcs_sensor = GCSObjectsWithPrefixExistenceSensor(
        task_id='gcs_sensor',
        bucket='zomoto_demo_bucket',
        prefix='food_orders_daily',
        mode='poke',
        poke_interval=60,
        timeout=300
    )

    # List and move the file
    list_files_task = PythonOperator(
        task_id='list_files',
        python_callable=list_files,
        op_kwargs={
            'bucket_name': 'zomoto_demo_bucket',
            'prefix': 'food_orders_daily'
        },
        do_xcom_push=True
    )

    # Launch Beam job
    beamtask = DataflowCreatePythonJobOperator(
        task_id="beam_task",
        py_file='gs://zomoto_demo_bucket/Beam.py',
        project_id='vast-arena-452608-m1',
        location='us-central1',
        job_name='food-orders-processing-{{ ds_nodash }}',
        options={
            "input": "gs://zomoto_demo_bucket/{{ ti.xcom_pull(task_ids='list_files') }}"
        }
    )

    gcs_sensor >> list_files_task >> beamtask
