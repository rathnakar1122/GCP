from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from datetime import datetime
import db_connection as db_conn
import pandas as pd 
from google.cloud import storage
from io import StringIO 
from airflow.models import Variable

# Fetching Airflow Variables
gcp_project_id = Variable.get("gcp_project_id")
gcs_bucket = Variable.get("gcp_bucket_name")
bq_dataset = Variable.get("bq_dataset")
db_secrets = Variable.get("db_secret_name")

def run_db_task():
    """Use the connection from db_connection.py"""
    conn, cursor = db_conn.conn_and_cursor_creation(gcp_project_id, db_secrets) 
    print("Database connection is established:", conn)
    cursor.execute("SELECT * FROM hmr_db.ticket;")
    rows = cursor.fetchall()

    gcs_bucket_name = gcs_bucket
    today = datetime.now()
    date_str = today.strftime("%Y_%m_%d")
    gcs_upload_blob_name = f"ticket_data_{date_str}.csv"

    client = storage.Client()
    bucket = client.bucket(gcs_bucket_name)
    
    columns = [desc[0] for desc in cursor.description]
    df = pd.DataFrame(rows, columns=columns)

    print(df)

    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    
    blob_modified = bucket.blob(gcs_upload_blob_name)
    blob_modified.upload_from_string(csv_buffer.getvalue(), content_type="text/csv")

    print("Modified DataFrame uploaded as ticket_data.csv in GCS")

# Default arguments
default_args = {
    "owner": "airflow", 
    "start_date": datetime(2024, 2, 20),
    "retries": 1,
}

# Define DAG
dag = DAG(
    "mysql_to_gcs_load_dag_v2",
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
)

# Define Tasks
run_task = PythonOperator(
    task_id="run_db_task", 
    python_callable=run_db_task,
    dag=dag,
)

trigger_next_dag = TriggerDagRunOperator(
    task_id="trigger_next_dag",
    trigger_dag_id="ticket_data_load_from_gcs_to_bigquery",
    dag=dag,
)

# Define task dependencies
run_task >> trigger_next_dag
