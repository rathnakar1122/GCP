from main import track_journey as tj
tj

import sys
sys.path.append('C:\ENV\PREP\2025\hyd_meto_project\modules\main.py')
from main import track_journey as tj
