import mysql.connector 

database = "hmr_db"

def db_connection():
    conn = mysql.connector.connect(
        #host='127.0.0.1', 
        host='localhost', port='3306',  user='root',  password='Yesurathnam@1990',  database=database,  
    )
    return conn

def conn_and_cursor_creation():
    conn = db_connection() 
    cursor = conn.cursor()
    return conn, cursor

conn_and_cursor_creation()
print("databse connected successfully")
