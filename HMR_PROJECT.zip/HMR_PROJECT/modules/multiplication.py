from test_module import multification as mul

num1 = int(input("Enter your first number: "))  # Fixed input formatting
num2 = int(input("Enter your second number: "))  # Removed extra int()

result = mul(num1, num2)  # Call the function
print("Multiplication result:", result)  # Print the result
