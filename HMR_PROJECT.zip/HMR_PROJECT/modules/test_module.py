import sqlite3
import os

#Databse connection

DB_name = "train_ticets.db"


if __name__