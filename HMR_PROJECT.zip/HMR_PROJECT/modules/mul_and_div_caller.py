from test_module import both_mul_and_div as md

num1 = int(input("Enter your first number: "))
num2 = int(input("Enter your second number: "))

result = md(num1, num2)  # Call the function and store the result

print("Result:", result)  # Print the result if it returns something
