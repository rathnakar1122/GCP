from main import add_station as ads
name = input("enter the Station Name :")
location = input("Enter the location name of the station:")
ads(name , location)

