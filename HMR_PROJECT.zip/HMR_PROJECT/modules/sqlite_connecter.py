

# python programe for connecting to sqlite3 and creating one table , inserting few records into it and then printing all the records from the table 

import sqlite3

DB_NAME = "ECOMMERCE_BUSINESS.DB"

# Establish connection
conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()

# SQL script to create the CUSTOMERS table
ddl_script = '''
CREATE TABLE IF NOT EXISTS CUSTOMERS (
    cust_id INTEGER PRIMARY KEY AUTOINCREMENT, 
    cust_name VARCHAR(100), 
    cust_age INTEGER,  
    cust_phone TEXT UNIQUE,  -- Changed to TEXT to avoid integer overflow
    cust_address VARCHAR(255) NOT NULL, 
    cust_email VARCHAR(100)  
);
'''
cursor.execute(ddl_script)

# Insert statement (corrected)
dml_insert_statement = '''
INSERT OR IGNORE INTO CUSTOMERS (cust_name, cust_phone, cust_email, cust_address) 
VALUES 
    ('Rathnakar', '7032123435', 'rathnkarmech@gmail.com', 'Mossapet')
    
    ;
'''

cursor.execute(dml_insert_statement)
conn.commit()

# Corrected SELECT statement
dq_select_statement = "SELECT * FROM CUSTOMERS;"
cursor.execute(dq_select_statement)
rows = cursor.fetchall()

for row in rows:
    print(row)

# Close the connection
conn.close()

print("Database operations completed successfully.")
