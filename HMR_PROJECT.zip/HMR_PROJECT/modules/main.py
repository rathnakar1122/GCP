import sqlite3
from datetime import datetime

# Database connection
DB_NAME = "train_ticketing.db"

def create_tables():
    """Creates the Station and Ticket tables if they don't exist."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Station (
            StationID INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            Location TEXT NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Ticket (
            TicketID INTEGER PRIMARY KEY AUTOINCREMENT,
            SourceStation INTEGER NOT NULL,
            DestinationStation INTEGER NOT NULL,
            Issue_Time DATETIME DEFAULT CURRENT_TIMESTAMP,
            Fare REAL NOT NULL,
            FOREIGN KEY (SourceStation) REFERENCES Station(StationID),
            FOREIGN KEY (DestinationStation) REFERENCES Station(StationID)
        )
    ''')

    conn.commit()
    conn.close()

def add_station(name, location):
    """Adds a new station."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Station (Name, Location) VALUES (?, ?)", (name, location))
    conn.commit()
    conn.close()
    print(f"Station '{name}' added successfully!")

def issue_ticket(source_station, destination_station, fare):
    """Issues a ticket for a journey."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    # Check if source and destination stations exist
    cursor.execute("SELECT StationID FROM Station WHERE StationID IN (?, ?)", (source_station, destination_station))
    stations = cursor.fetchall()
    if len(stations) < 2:
        print("Invalid station IDs! Please check and try again.")
        return

    # Insert ticket record
    issue_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("INSERT INTO Ticket (SourceStation, DestinationStation, Issue_Time, Fare) VALUES (?, ?, ?, ?)",
                   (source_station, destination_station, issue_time, fare))
    conn.commit()
    print(f"Ticket issued successfully from Station {source_station} to Station {destination_station}.")
    conn.close()

def get_ticket(ticket_id):
    """Retrieves ticket details."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT T.TicketID, S1.Name AS Source, S2.Name AS Destination, T.Issue_Time, T.Fare
        FROM Ticket T
        JOIN Station S1 ON T.SourceStation = S1.StationID
        JOIN Station S2 ON T.DestinationStation = S2.StationID
        WHERE T.TicketID = ?
    ''', (ticket_id,))
    
    ticket = cursor.fetchone()
    conn.close()

    if ticket:
        print(f"🎟 Ticket ID: {ticket[0]}")
        print(f"🚉 Source: {ticket[1]}")
        print(f"🚆 Destination: {ticket[2]}")
        print(f"🕒 Issued At: {ticket[3]}")
        print(f"💰 Fare: ${ticket[4]:.2f}")
    else:
        print("Ticket not found!")

def track_journey(ticket_id):
    """Tracks a journey using a ticket ID."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT S1.Name AS Source, S2.Name AS Destination
        FROM Ticket T
        JOIN Station S1 ON T.SourceStation = S1.StationID
        JOIN Station S2 ON T.DestinationStation = S2.StationID
        WHERE T.TicketID = ?
    ''', (ticket_id,))

    journey = cursor.fetchone()
    conn.close()

    if journey:
        print(f"Train Journey: 🚉 {journey[0]} ➝ 🚆 ➝ {journey[1]}")
    else:
        print("Invalid ticket ID!")

if __name__ == "__main__":
    create_tables() 

    # Sample Data (Uncomment to add stations)
    # add_station("New York Central", "New York")
    # add_station("Chicago Union", "Chicago")
    # add_station("Los Angeles Terminal", "Los Angeles")

    # Issue a ticket (Uncomment to test)
    # issue_ticket(1, 2, 50.00)

    # Get ticket details (Uncomment to test)
    # get_ticket(1)

    # Track a journey (Uncomment to test)
    # track_journey(1)