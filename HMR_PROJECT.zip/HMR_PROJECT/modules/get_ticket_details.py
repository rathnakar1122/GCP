from main import get_tickets as gt
id = input ("enter ticker id")
gt(id)