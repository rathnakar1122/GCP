from test_module import addition as add

num1 = int(input("Enter your first number: "))
num2 = int(input("Enter your second number: "))

result = add(num1, num2)
#print("The sum is:", result)
