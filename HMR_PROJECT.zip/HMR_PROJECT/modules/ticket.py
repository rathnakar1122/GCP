from main import issue_ticket as it 

source_station = input("Enter the source station: ")
destination_station = input("Enter the destination: ")
fare = 100

it(source_station, destination_station, fare)  # Closing parenthesis added
