INSERT INTO fare (Start_Station, End_Station, Points, Traveled_Fare) VALUES 
('Miyapur', 'Ameerpet', 10, 20),
('Miyapur', 'MG Bus Station', 19, 38),
('Miyapur', 'L B Nagar', 26, 52),
('Ameerpet', 'Miyapur', 10, 20),
('Ameerpet', 'MG Bus Station', 9, 18),
('Ameerpet', 'L B Nagar', 16, 32),
('MG Bus Station', 'Miyapur', 19, 38),
('MG Bus Station', 'Ameerpet', 9, 18),
('MG Bus Station', 'L B Nagar', 7, 14),
('L B Nagar', 'Miyapur', 26, 52),
('L B Nagar', 'Ameerpet', 16, 32),
('L B Nagar', 'MG Bus Station', 7, 14);

