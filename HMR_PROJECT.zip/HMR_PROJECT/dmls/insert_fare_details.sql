INSERT INTO FARE (START_STATION, END_STATION, POINTS, TRAVELED_FARE) VALUES 
('Miyapur', 'Ameerpet', 10, 20),
('Miyapur', 'MG Bus Station', 19, 38),
('Miyapur', 'LB Nagar', 10, 20),
('Ameerpet', 'Miyapur', 10, 20),
('Ameerpet', 'MG Bus Station', 9, 18),
('Ameerpet', 'LB Nagar', 16, 32),
('MG Bus Station', 'Miyapur', 19, 38),
('MG Bus Station', 'LB Nagar', 7, 14),
('LB Nagar', 'Miyapur', 26, 52),
('LB Nagar', 'MG Bus Station', 7, 14);
