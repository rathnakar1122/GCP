list_of_stations_with_points_gap = [1, 20, 2, 9, 3, 7, 4]

def source_destination_ids_check(s_s_id, t_s_id):
    if s_s_id == t_s_id:
        print("Your source and target stations are the same. Please select different ones.")
        return False  # Return False if they are the same
    return True

def main():
    s_s_id = int(input("Enter the source station ID: "))
    t_s_id = int(input("Enter the target station ID: "))

    if not source_destination_ids_check(s_s_id, t_s_id):
        return  # Exit if source and destination are the same

    fare = False

    if not fare:
        print("Fare is not set")
        for idx, v in enumerate(list_of_stations_with_points_gap):
            print(f"Index: {idx}, Station ID: {v}")  # Now prints index and station ID




if __name__ == "__main__":
    main()
