import pandas as pd
import os 

#csv_file_path = r'C:\ENV\PREP\2025\python\data\customer.csv'
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"C:\ENV\rathnakar-18m85a0320-hiscox-0d1ad7b79faf.json"

csv_file_path = r'gs://csv-file-data/customer.csv'

df = pd.read_csv(csv_file_path, encoding='utf-8', on_bad_lines='skip')

print(df.head())
df.head()
# it displys top 5 records 
df.head()
df.tail() # it displays the lowest 5 records
df.head(10)
df.tail # it will print the last 5 records 
df.tail(16).head(5) # it makes the data right from 11 to the last records then retake right from 11 to 15 records 
df.info() 