CREATE TABLE IF NOT EXISTS Ticket (
    TicketID INTEGER PRIMARY KEY AUTOINCREMENT,
    Date_and_Time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    from_location TEXT NOT NULL,
    to_location TEXT NOT NULL,
    price REAL NOT NULL, 
    ticket_type TEXT NOT NULL
);
