CREATE TABLE IF NOT EXISTS fare(
    Start_Station text not null,	
    End_Station	 text not null,
    Points integer not null,
    Traveled_Fare integer not null

)