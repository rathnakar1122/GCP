-- ddl scripts development
-- entity

CREATE TABLE IF NOT EXISTS stations_info(
    station_id INTEGER PRIMARY KEY AUTOINCREMENT,         -- Unique identifier for each station
    station_name VARCHAR(255) NOT NULL,                -- Name of the station
    location VARCHAR(255),                             -- Location or address of the station 
    opening_date DATE,                                 -- Date when the station opened
    status VARCHAR(50) DEFAULT 'Active'               -- Status of the station (Active/Inactive)
);