CREATE TABLE IF NOT EXISTS ticket (  
    Ticket_ID INTEGER PRIMARY KEY AUTOINCREMENT,  
    Date_And_Time TEXT NOT NULL DEFAULT (DATETIME('now', 'localtime')),  
    From_Location TEXT NOT NULL,  
    To_Location TEXT NOT NULL,  
    Price REAL NOT NULL,  
    Ticket_Type TEXT NOT NULL  
);
