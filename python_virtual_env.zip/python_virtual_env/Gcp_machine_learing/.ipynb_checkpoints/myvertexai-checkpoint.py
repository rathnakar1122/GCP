from google.auth.transport.requests import Request  
from google.oauth2.service_account import Credentials  
import vertexai  

# Define API key path  
api_key_path = 'hopeful-land-452112-j5-47b5f18a317f.json'  

# Define project and region  
PROJECT_ID = 'hopeful-land-452112-j5'  
REGION_ID = 'us-central1'  # Google Cloud regions should be lowercase  

# Load credentials  
credentials = Credentials.from_service_account_file(
    api_key_path, 
    scopes=["https://www.googleapis.com/auth/cloud-platform"]
)  

# Initialize Vertex AI  
vertexai.init(project=PROJECT_ID, location=REGION_ID, credentials=credentials)
